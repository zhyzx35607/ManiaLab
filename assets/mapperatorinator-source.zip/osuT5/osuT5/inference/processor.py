from __future__ import annotations

import time as _time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import numpy as np
import torch
import torch.nn.functional as F
from slider import Beatmap, TimingPoint
from tqdm import tqdm

from config import InferenceConfig
from .compiled_decode import model_generate_compiled
from .server import InferenceClient, model_generate, model_forward, precompute_encoder_outputs
from ..dataset.osu_parser import OsuParser
from ..dataset.data_utils import (update_event_times, remove_events_of_type, get_hold_note_ratio,
                                  get_scroll_speed_ratio, get_hitsounded_status, calculate_difficulty)
from ..model import Mapperatorinator
from ..tokenizer import Event, EventType, Tokenizer, ContextType

MILISECONDS_PER_SECOND = 1000
MILISECONDS_PER_STEP = 10


@dataclass
class GenerationConfig:
    gamemode: int = 0
    beatmap_id: Optional[int] = None
    difficulty: Optional[float] = None
    mapper_id: Optional[int] = None
    year: Optional[int] = None
    hitsounded: bool = True
    hp_drain_rate: Optional[float] = None
    circle_size: Optional[float] = None
    overall_difficulty: Optional[float] = None
    approach_rate: Optional[float] = None
    slider_multiplier: float = 1.4
    slider_tick_rate: Optional[float] = None
    keycount: int = 4
    hold_note_ratio: Optional[float] = None
    scroll_speed_ratio: Optional[float] = None
    descriptors: Optional[list[str]] = None
    negative_descriptors: Optional[list[str]] = None


# noinspection PyProtectedMember
def generation_config_from_beatmap(beatmap: Beatmap, beatmap_path, tokenizer: Optional[Tokenizer] = None) -> GenerationConfig:
    gamemode = int(beatmap.mode)
    difficulty = calculate_difficulty(path=beatmap_path)

    return GenerationConfig(
        gamemode=gamemode,
        beatmap_id=beatmap.beatmap_id,
        difficulty=difficulty,
        mapper_id=tokenizer.beatmap_mapper.get(beatmap.beatmap_id, None) if tokenizer else None,
        hp_drain_rate=beatmap.hp_drain_rate,
        circle_size=beatmap.circle_size,
        overall_difficulty=beatmap.overall_difficulty,
        approach_rate=beatmap.approach_rate,
        slider_multiplier=beatmap.slider_multiplier,
        slider_tick_rate=beatmap.slider_tick_rate,
        hitsounded=get_hitsounded_status(beatmap),
        keycount=int(beatmap.circle_size) if gamemode == 3 else 4,
        hold_note_ratio=get_hold_note_ratio(beatmap) if gamemode == 3 else None,
        scroll_speed_ratio=get_scroll_speed_ratio(beatmap) if gamemode in [1, 3] else None,
        descriptors=[tokenizer.descriptor_name(idx) for idx in tokenizer.beatmap_descriptors.get(beatmap.beatmap_id, [])] if tokenizer and beatmap.beatmap_id in tokenizer.beatmap_descriptors else None,
    )


class Processor(object):
    def __init__(self, args: InferenceConfig, model: Mapperatorinator | InferenceClient, tokenizer: Tokenizer, cfg_scale: float = None):
        """Model inference stage that processes sequences."""
        self.device = args.device
        self.precision = args.precision
        self.args = args
        self.model = model
        self.tokenizer = tokenizer
        self.tgt_seq_len = args.train.data.tgt_seq_len
        self.frame_seq_len = args.train.data.src_seq_len - 1
        self.frame_size = args.train.model.spectrogram.hop_length
        self.sample_rate = args.train.model.spectrogram.sample_rate
        self.samples_per_sequence = self.frame_seq_len * self.frame_size
        self.miliseconds_per_sequence = self.samples_per_sequence * MILISECONDS_PER_SECOND / self.sample_rate
        self.lookback_time = args.lookback * self.miliseconds_per_sequence
        self.lookback_time_range = range(tokenizer.event_start[EventType.TIME_SHIFT], tokenizer.encode(Event(EventType.TIME_SHIFT, int(self.lookback_time / MILISECONDS_PER_STEP))))
        self.lookahead_max_time = (1 - args.lookahead) * self.miliseconds_per_sequence
        self.lookahead_time = args.lookahead * self.miliseconds_per_sequence
        self.lookahead_time_range = range(tokenizer.encode(Event(EventType.TIME_SHIFT, int(self.lookahead_max_time / MILISECONDS_PER_STEP))), tokenizer.event_end[EventType.TIME_SHIFT])
        self.eos_time = (1 - args.train.data.lookahead) * self.miliseconds_per_sequence
        self.center_pad_decoder = args.train.data.center_pad_decoder
        # All Special Prefix Tokens
        self.add_out_context_types = args.train.data.add_out_context_types
        self.add_gamemode_token = args.train.data.add_gamemode_token
        self.add_style_token = args.train.data.add_style_token
        self.add_diff_token = args.train.data.add_diff_token
        self.add_mapper_token = args.train.data.add_mapper_token
        self.add_year_token = args.train.data.add_year_token
        self.add_hitsounded_token = args.train.data.add_hitsounded_token
        self.add_song_length_token = args.train.data.add_song_length_token
        self.add_global_sv_token = args.train.data.add_global_sv_token
        self.add_cs_token = args.train.data.add_cs_token
        self.add_keycount_token = args.train.data.add_keycount_token
        self.add_hold_note_ratio_token = args.train.data.add_hold_note_ratio_token
        self.add_scroll_speed_ratio_token = args.train.data.add_scroll_speed_ratio_token
        self.add_descriptors = args.train.data.add_descriptors
        self.add_sv_special_token = args.train.data.add_sv_special_token
        self.add_kiai_special_token = args.train.data.add_kiai_special_token
        self.add_song_position_token = args.train.data.add_song_position_token
        # ---
        self.add_kiai = args.train.data.add_kiai
        self.max_pre_token_len = args.train.data.max_pre_token_len
        self.add_pre_tokens = args.train.data.add_pre_tokens
        self.add_gd_context = args.train.data.add_gd_context
        self.add_timing = args.train.data.add_timing
        self.parser = OsuParser(args.train, self.tokenizer)
        self.do_style_embed = args.train.model.do_style_embed
        self.do_difficulty_embed = args.train.model.do_difficulty_embed
        self.do_mapper_embed = args.train.model.do_mapper_embed
        self.do_song_position_embed = args.train.model.do_song_position_embed
        self.add_positions = args.train.data.add_positions
        self.add_sv = args.train.data.add_sv
        self.add_mania_sv = args.train.data.add_mania_sv
        self.context_types: list[dict[str, list[ContextType]]] = \
            [{k: [ContextType(t) for t in v] for k, v in ct.items()} for ct in args.train.data.context_types]
        self.add_to_beatmap = args.add_to_beatmap
        self.start_time = args.start_time
        self.end_time = args.end_time

        if self.add_positions:
            self.position_precision = args.train.data.position_precision
            self.position_refinement = args.train.data.position_refinement
            x_min, x_max, y_min, y_max = args.train.data.position_range
            self.x_min = x_min // self.position_precision
            self.x_max = x_max // self.position_precision
            self.y_min = y_min // self.position_precision
            self.y_max = y_max // self.position_precision
            self.x_count = self.x_max - self.x_min + 1

        self.cfg_scale = cfg_scale or args.cfg_scale
        self.top_p = args.top_p
        self.top_k = args.top_k
        self.temperature = args.temperature
        self.timing_temperature = args.timing_temperature
        self.mania_column_temperature = args.mania_column_temperature
        self.taiko_hit_temperature = args.taiko_hit_temperature
        self.do_sample = args.do_sample
        self.num_beams = args.num_beams
        self.parallel = args.parallel
        self.max_batch_size = args.max_batch_size

        self.timeshift_bias = args.timeshift_bias
        self.types_first = args.train.data.types_first
        # CUDA-graph fast decoder loop (see compiled_decode.py). Requires CUDA;
        # inference.py disables it on other devices. When the model is an
        # InferenceClient this flag lives on the server instead.
        self.fast_decoder_loop = args.fast_decoder_loop
        self.last_generation_stats: dict[str, float | int] | None = None

    def model_generate(self, model_kwargs, **generate_kwargs: Any) -> Any:
        generate_kwargs2 = generate_kwargs | dict(
            precision=self.precision,
            do_sample=self.do_sample,
            num_beams=self.num_beams,
            top_p=self.top_p,
            top_k=self.top_k,
            max_length=self.tgt_seq_len,
            cfg_scale=self.cfg_scale,
            timeshift_bias=self.timeshift_bias,
            types_first=self.types_first,
            temperature=self.temperature,
            timing_temperature=self.timing_temperature,
            mania_column_temperature=self.mania_column_temperature,
            taiko_hit_temperature=self.taiko_hit_temperature,
        )

        if isinstance(self.model, InferenceClient):
            response = self.model.generate(model_kwargs, generate_kwargs2)
            return response, getattr(self.model, "last_generation_stats", None)
        # Batch-1 requests with precomputed encoder outputs go through the fast
        # decoder loop when enabled (it is captured for a fixed batch size and
        # cannot do beam search). With an InferenceClient the equivalent dispatch
        # happens on the server.
        if (self.fast_decoder_loop
                and isinstance(model_kwargs.get('encoder_outputs'), torch.Tensor)
                and model_kwargs['encoder_outputs'].shape[0] == 1
                and self.num_beams == 1):
            return model_generate_compiled(self.model, self.tokenizer, model_kwargs, generate_kwargs2)
        return model_generate(self.model, self.tokenizer, model_kwargs, generate_kwargs2)

    def model_forward(self, model_kwargs) -> Any:
        generate_kwargs2 = dict(
            precision=self.precision,
            cfg_scale=self.cfg_scale,
        )

        if isinstance(self.model, InferenceClient):
            raise NotImplementedError("Logits generation is not supported in InferenceClient.")
        else:
            return model_forward(self.model, model_kwargs, generate_kwargs2)

    def generate(
            self,
            *,
            sequences: tuple[torch.Tensor, torch.Tensor, float],
            generation_config: GenerationConfig,
            in_context: list[ContextType] = None,
            out_context: list[ContextType] = None,
            beatmap_path: Optional[str] = None,
            extra_in_context: Optional[dict[ContextType, tuple[list[Event], list[int]] | tuple[list[Event], list[int], torch.Tensor] | list[TimingPoint]]] = None,
            verbose: bool = True,
    ) -> list[tuple[list[Event], list[int]]]:
        """Generate a list of Event object lists and their timestamps given source sequences.

        Args:
            sequences: A list of batched source sequences, and the total song length in milliseconds.
            generation_config: Generation configuration.
            in_context: List of context information.
            out_context: Output contexts to generate.
            beatmap_path: Path to the beatmap file for context generation.
            extra_in_context: Extra context information to use instead of beatmap_path.
            verbose: Whether to show progress bar.

        Returns:
            events: List of Event object lists.
            event_times: Corresponding event times of Event object lists in miliseconds.
        """
        gen_in_context, gen_out_context, req_special_tokens = self._get_viable_template(
            in_context=in_context,
            out_context=out_context,
            extra_in_context=extra_in_context,
            gamemode=generation_config.gamemode,
        )

        model_kwargs = self._get_model_cond_kwargs(generation_config)
        song_length = sequences[2]
        in_context_data = self.get_in_context(
            in_context=gen_in_context,
            beatmap_path=beatmap_path,
            extra_in_context=extra_in_context,
            song_length=song_length,
        )
        out_context_data = self.get_out_context(
            out_context=gen_out_context,
            generation_config=generation_config,
            given_context=in_context,
            beatmap_path=beatmap_path,
            extra_in_context=extra_in_context,
            song_length=song_length,
            verbose=verbose,
        )

        # Start generation
        inputs = dict(
            sequences=sequences,
            in_context=in_context_data,
            out_context=out_context_data,
            model_kwargs=model_kwargs,
            req_special_tokens=req_special_tokens,
            verbose=verbose,
        )

        generate_func = self.generate_parallel if self.parallel else self.generate_sequential
        self._reset_generation_stats()
        if isinstance(self.model, InferenceClient):
            with self.model:
                generate_func(**inputs)
        else:
            generate_func(**inputs)

        # Post-process events
        for context in out_context_data:
            # Regenerate event times
            context["event_times"] = []
            update_event_times(context["events"], context["event_times"], song_length, self.types_first)

            # Trim events to start and end time
            # Add extra leniency because generated events may not be exactly on time
            if self.start_time is not None:
                self._trim_events_before_time(context["events"], context["event_times"], self.start_time - 10)
            if self.end_time is not None:
                self._trim_events_after_time(context["events"], context["event_times"], self.end_time + 10)

            # Rescale and unpack position events
            if context["context_type"] == ContextType.MAP and self.add_positions:
                context["events"], context["event_times"] = self._rescale_positions(context["events"], context["event_times"])

        # If we are adding to beatmap, add back the events of the reference beatmap
        if self.add_to_beatmap and (self.start_time is not None or self.end_time is not None):
            parser = OsuParser(self.args.train, self.tokenizer)
            parser.position_precision = 1
            parser.position_split_axes = True
            for context in out_context_data:
                ref_context = self.get_context(
                    context["context_type"],
                    beatmap_path=beatmap_path,
                    extra_in_context=extra_in_context,
                    finished=True,
                    parser=parser,
                )
                if self.start_time is not None:
                    ref_events, ref_event_times = ref_context["events"].copy(), ref_context["event_times"].copy()
                    self._trim_events_after_time(ref_events, ref_event_times, self.start_time - 1)
                    context["events"] = ref_events + context["events"]
                    context["event_times"] = ref_event_times + context["event_times"]
                if self.end_time is not None:
                    ref_events, ref_event_times = ref_context["events"].copy(), ref_context["event_times"].copy()
                    self._trim_events_before_time(ref_events, ref_event_times, self.end_time + 1)
                    context["events"] += ref_events
                    context["event_times"] += ref_event_times

        # Turn mania key column into X position
        for context in out_context_data:
            if context["context_type"] != ContextType.MAP or generation_config.gamemode != 3:
                continue

            context["events"], context["event_times"] = self._convert_column_to_position(context["events"], context["event_times"], generation_config.keycount)

        return [(context["events"], context["event_times"]) for context in out_context_data if context["context_type"] in out_context]

    def generate_sequential(
            self,
            *,
            sequences: tuple[torch.Tensor, torch.Tensor, float],
            in_context: list[dict[str, Any]],
            out_context: list[dict[str, Any]],
            model_kwargs: dict[str, Any],
            req_special_tokens: list[str],
            verbose: bool = True,
    ):
        """Generate windows sequentially, reusing encoder outputs precomputed in a
        single batched pass before the decode loop. Each window skips the
        per-window encoder prefill; the encoder is a pure function of the audio
        window + static conditioning, so hoisting it out of the sequential loop
        changes only timing, not values.
        """
        song_length = sequences[2]
        all_frames = self.prepare_frames(sequences[0])  # (N, L_raw)
        frame_times = sequences[1]
        n_windows = all_frames.shape[0]

        # Static conditioning broadcast across windows (beatmap_idx/difficulty/mapper_idx)
        cond_kwargs = {k: v for k, v in model_kwargs.items()
                       if k in ("beatmap_idx", "difficulty", "mapper_idx") and isinstance(v, torch.Tensor)}

        # Per-window song positions
        if self.do_song_position_embed:
            starts = (frame_times / song_length).to(torch.float32)
            ends = ((frame_times + self.miliseconds_per_sequence) / song_length).to(torch.float32)
            song_positions = torch.stack([starts, ends], dim=1)  # (N, 2)
        else:
            song_positions = None

        # Precompute encoder outputs for all windows in one batched pass
        t0 = _time.perf_counter() if verbose else 0
        if verbose:
            print(f"Precomputing encoder outputs for {n_windows} windows...")
        if isinstance(self.model, InferenceClient):
            # The client doesn't own the model, so the server precomputes.
            # Conditioning is expanded per window because the server may split
            # the request into multiple batches.
            precompute_kwargs = {k: v.expand(n_windows).contiguous() for k, v in cond_kwargs.items()}
            precompute_kwargs["inputs"] = all_frames
            if song_positions is not None:
                precompute_kwargs["song_position"] = song_positions
            enc_hidden = self.model.precompute_encoder(precompute_kwargs)  # (N, L_enc, D)
        else:
            with torch.no_grad():
                enc_hidden = precompute_encoder_outputs(
                    self.model, all_frames, cond_kwargs, song_positions,
                    batch_size=self.max_batch_size,
                )
        if verbose:
            print(f"Encoder precompute: {_time.perf_counter() - t0:.2f}s "
                  f"({(_time.perf_counter() - t0) / n_windows * 1000:.1f} ms/window)")

        for i, context in enumerate(out_context):
            if context["finished"]:
                continue

            if verbose:
                print(f"Generating {context['context_type'].value}")
            tokens_per_second_meter = self._create_tokens_per_second_meter()
            iterator = tqdm(list(zip(range(n_windows), frame_times)), dynamic_ncols=True) if verbose else zip(range(n_windows), frame_times)
            for sequence_index, (wi, frame_time) in enumerate(iterator):
                trim_lookback = sequence_index != 0 and self.lookback_time > 0
                trim_lookahead = sequence_index != n_windows - 1
                frame_time = frame_time.item()

                # Get relevant tokens for current frame
                cond_prompt, uncond_prompt = self.get_prompts(
                    self.prepare_context_sequences(in_context, frame_time, False, req_special_tokens),
                    self.prepare_context_sequences(out_context[:i + 1], frame_time, True, req_special_tokens),
                )

                [prompt, uncond_prompt], max_len = self.pad_prompts([cond_prompt, uncond_prompt])

                result, generation_stats = self.model_generate(
                    model_kwargs | dict(
                        encoder_outputs=enc_hidden[wi:wi + 1],
                        decoder_input_ids=prompt,
                        decoder_attention_mask=prompt.ne(self.tokenizer.pad_id),
                        negative_prompt=uncond_prompt,
                        negative_prompt_attention_mask=uncond_prompt.ne(self.tokenizer.pad_id) if uncond_prompt is not None else None,
                    ),
                    lookback_time=self.lookback_time if trim_lookback else 0,
                    lookahead_time=self.lookahead_time if trim_lookahead else 0,
                    context_type=context["context_type"].value,
                )
                self._record_generation_stats(generation_stats)
                if verbose:
                    self._update_tokens_per_second_meter(iterator, tokens_per_second_meter, generation_stats)

                # Only support batch size 1
                predicted_tokens = result[0, max_len:].cpu()
                self.add_predicted_tokens_to_context(context, predicted_tokens, frame_time, trim_lookback, trim_lookahead)

    def generate_parallel(
            self,
            *,
            sequences: tuple[torch.Tensor, torch.Tensor, float],
            in_context: list[dict[str, Any]],
            out_context: list[dict[str, Any]],
            model_kwargs: dict[str, Any],
            req_special_tokens: list[str],
            verbose: bool = True,
    ):
        # Get relevant inputs
        frames = self.prepare_frames(sequences[0])
        frame_times = sequences[1]
        song_length = sequences[2]

        cond_prompts, uncond_prompts, model_kwargses = self._prepare_parallel_inputs(
            frame_times=frame_times,
            song_length=song_length,
            in_context=in_context,
            out_context=out_context[:1],
            model_kwargs=model_kwargs,
            req_special_tokens=req_special_tokens,
        )
        result = self._batched_inference(
            self.model_generate,
            cond_prompts,
            uncond_prompts,
            frames,
            model_kwargses,
            verbose,
        )

        sequence_index = 0
        for batch, _ in result:
            for sequence in batch:
                frame_time = frame_times[sequence_index].item()
                if self.add_out_context_types:
                    for context in out_context:
                        # Find the tokens in predicted_tokens[i] between context sos and eos
                        start, end = self._get_token_context(
                            sequence,
                            self.tokenizer.context_sos[context["context_type"]],
                            self.tokenizer.context_eos[context["context_type"]],
                            strict=True,
                        )
                        self.add_predicted_tokens_to_context(context, sequence[start:end], frame_time)
                else:
                    start, end = self._get_token_context(sequence, self.tokenizer.sos_id, self.tokenizer.eos_id)
                    self.add_predicted_tokens_to_context(out_context[0], sequence[start:end], frame_time)
                sequence_index += 1

    def ai_mod(
            self,
            *,
            sequences: tuple[torch.Tensor, torch.Tensor, float],
            generation_config: GenerationConfig,
            beatmap_path: Optional[str] = None,
            verbose: bool = True,
    ):
        gen_in_context, gen_out_context, req_special_tokens = self._get_viable_template(
            gamemode=generation_config.gamemode,
        )

        model_kwargs = self._get_model_cond_kwargs(generation_config)
        song_length = sequences[2]
        in_context_data = self.get_in_context(
            in_context=gen_in_context,
            beatmap_path=beatmap_path,
            song_length=song_length,
        )
        out_context_data = self.get_out_context(
            out_context=gen_out_context,
            generation_config=generation_config,
            given_context=gen_out_context,  # All the context is given so the events will be filled in
            beatmap_path=beatmap_path,
            song_length=song_length,
            verbose=verbose,
        )

        # Get relevant inputs
        frames = self.prepare_frames(sequences[0])
        frame_times = sequences[1]
        song_length = sequences[2]

        cond_prompts, uncond_prompts, model_kwargses = self._prepare_parallel_inputs(
            frame_times=frame_times,
            song_length=song_length,
            in_context=in_context_data,
            out_context=out_context_data,
            model_kwargs=model_kwargs,
            req_special_tokens=req_special_tokens,
        )

        for context in out_context_data:
            context['surprisals'] = np.zeros(len(context["events"]), dtype=np.float32)
            context['expected_events'] = np.array(context["events"], dtype=np.object_)
            context['expected_events_str'] = np.empty(len(context["events"]), dtype=np.object_)
            context['events_str'] = np.empty(len(context["events"]), dtype=np.object_)

        results = self._batched_inference(
            self.model_forward,
            cond_prompts,
            uncond_prompts,
            frames,
            model_kwargses,
            verbose=verbose,
        )

        sequence_index = 0
        for batch, _ in results:
            for result in batch:
                for context in out_context_data:
                    trim_lookback = sequence_index != 0
                    trim_lookahead = sequence_index != len(sequences[0]) - 1

                    frame_time = frame_times[sequence_index].item()

                    # Get relevant tokens for current frame
                    s, e = self._get_events_time_range(context["event_times"], frame_time, frame_time + self.miliseconds_per_sequence)
                    events, event_times = context["events"][s:e], context["event_times"][s:e]
                    tokens = self._encode(events, frame_time).squeeze(0)
                    seq_prompt = cond_prompts[sequence_index].squeeze(0)
                    padding = result.shape[0] - len(seq_prompt)

                    # Get the range within the current frame with lookback and lookahead removed
                    window_start_t = frame_time + self.lookback_time if trim_lookback else frame_time
                    window_end_t = frame_time + self.lookahead_max_time if trim_lookahead else frame_time + self.miliseconds_per_sequence
                    s2, e2 = self._get_events_time_range(event_times, window_start_t, window_end_t)

                    # Find the tokens in predicted_tokens[i] between context sos and eos
                    if self.add_out_context_types:
                        start, end = self._get_token_context(
                            seq_prompt,
                            self.tokenizer.context_sos[context["context_type"]],
                            self.tokenizer.context_eos[context["context_type"]],
                            strict=True,
                        )
                    else:
                        start, end = self._get_token_context(seq_prompt, self.tokenizer.sos_id, self.tokenizer.eos_id)

                    # Shift start and end because we want to get the logits for the event instead of the next event
                    logits = result[start + padding - 1:end + padding - 1]
                    assert len(logits) == len(events), f"Logits length {len(logits)} does not match events length {len(events)} for context {context['context_type']} at frame {sequence_index}."

                    # Cut the tokens and logits to the generation window
                    tokens = tokens[s2:e2]
                    logits = logits[s2:e2]

                    # Calculate surprisal and relative surprisal
                    probs = logits.softmax(dim=-1)
                    entropy = -torch.sum(probs * torch.log2(probs + 1e-10), dim=-1)
                    surprisal = -torch.log2(probs[torch.arange(len(tokens)), tokens] + 1e-10)
                    relative_surprisal = torch.where(entropy > 0, surprisal / entropy, torch.zeros_like(entropy))

                    # Get the most likely token as a suggestion for a fix
                    suggested_tokens = logits.argmax(dim=-1)
                    suggested_events = self._decode(suggested_tokens, frame_time, True)

                    context['surprisals'][s:e][s2:e2] = relative_surprisal
                    context['expected_events'][s:e][s2:e2] = suggested_events

                    # Post-process events
                    def process_event(event: Event) -> Any:
                        offset = self.position_precision // 2 if self.position_precision > 1 else 0
                        # Rescale position events
                        if event.type == EventType.POS_X or event.type == EventType.POS_Y:
                            return f"{event.type.value[4]}:{event.value * self.position_precision}"
                        elif event.type == EventType.POS:
                            return f"x:{((event.value % self.x_count) + self.x_min) * self.position_precision + offset} y:{((event.value // self.x_count) + self.y_min) * self.position_precision + offset}"
                        # Convert distance events to string
                        elif event.type == EventType.DISTANCE:
                            return f"{event.value}"
                        # Convert mania column to string
                        elif event.type == EventType.MANIA_COLUMN:
                            return f"{event.value + 1}"
                        # Convert volume to string
                        elif event.type == EventType.VOLUME:
                            return f"{event.value}%"
                        # Convert snapping events to string
                        elif event.type == EventType.SNAPPING:
                            return f"1/{event.value}" if event.value > 0 else "none"
                        # Convert time shift events to string mm:ss:fff
                        elif event.type == EventType.TIME_SHIFT:
                            timestamp = f"{event.value // 60000:02}:{(event.value // 1000) % 60:02}:{event.value % 1000:03}"
                            return f"[link=osu://edit/{timestamp}]{timestamp}[/link]"
                        # Convert SV events to string
                        elif event.type == EventType.SCROLL_SPEED:
                            return f"x{(event.value / 100):.2f}"
                        # Convert hitsound events to string
                        elif event.type == EventType.HITSOUND:
                            hitsound_map = ["whistle", "finish", "clap"]
                            hitsounds = [hitsound_map[i] for i in range(3) if (event.value >> i) & 1]
                            sampleset_map = ["normal", "soft", "drum"]
                            sampleset = ((event.value // 8) % 3)
                            additions = ((event.value // 24) % 3)
                            return f"{sampleset_map[sampleset]}:{sampleset_map[additions]}-{':'.join(hitsounds) if hitsounds else 'none'}"
                        # Convert EOS control events to string
                        elif event.type == EventType.CONTROL and event.value in [self.tokenizer.eos_id] + list(self.tokenizer.context_eos.values()):
                            return f"End of sequence"
                        else:
                            return event

                    for i, event in enumerate(context['events'][s:e][s2:e2]):
                        context['events_str'][s:e][s2:e2][i] = process_event(event)
                    for i, event in enumerate(context['expected_events'][s:e][s2:e2]):
                        context['expected_events_str'][s:e][s2:e2][i] = process_event(event)

                sequence_index += 1

        return out_context_data

    def _get_viable_template(
            self,
            in_context: Optional[list[ContextType]] = None,
            out_context: Optional[list[ContextType]] = None,
            extra_in_context: Optional[dict[ContextType, tuple[list[Event], list[int]] | tuple[list[Event], list[int], torch.Tensor] | list[TimingPoint]]] = None,
            gamemode: int = 0,
    ):
        in_context = in_context or []
        out_context = out_context or []
        requested_out_context = out_context.copy()

        # Merge extra in context with in context
        if extra_in_context is not None:
            in_context = in_context.copy()
            for context_type in extra_in_context:
                if context_type not in in_context:
                    in_context.append(context_type)

        # Find a viable context generation template
        viable_templates = [
            context_type for context_type in self.context_types if
            all(oc in context_type["out"] for oc in out_context) and all(
                ic in in_context or ic == ContextType.NONE for ic in context_type["in"])
        ]

        if len(viable_templates) == 0:
            raise ValueError(
                "No viable template found for the given context types. Candidates are: " + str(self.context_types))

        # Use the template with the most non-none in context
        template = max(viable_templates, key=lambda ct: sum(1 for ic in ct["in"] if ic != ContextType.NONE))
        all_out_context = template["out"]
        gen_out_context = all_out_context.copy()
        gen_in_context = template["in"].copy()

        # Get the required special tokens for this template
        req_special_tokens = self.get_required_extra_special_tokens(all_out_context)

        # Only generate SV in mania mode
        if gamemode != 3:
            if ContextType.SV in gen_out_context:
                gen_out_context.remove(ContextType.SV)

        # We have to generate the out contexts in order of the template
        requested_out_context_was_explicit = len(requested_out_context) > 0
        requested_out_context = [oc for oc in requested_out_context if oc in gen_out_context]
        if len(requested_out_context) == 0:
            if requested_out_context_was_explicit:
                raise ValueError("No requested output contexts are available for the selected template and gamemode.")
            gen_out_context = all_out_context.copy()
        else:
            out_context_count = max(all_out_context.index(oc) for oc in requested_out_context) + 1
            gen_out_context = all_out_context[:out_context_count]

        return gen_in_context, gen_out_context, req_special_tokens

    def _get_model_cond_kwargs(
            self,
            generation_config: GenerationConfig,
    ) -> dict[str, torch.Tensor]:
        # Prepare special conditioning input for model kwargs
        model_kwargs = {}
        if self.do_style_embed:
            if generation_config.beatmap_id is not None:
                model_kwargs["beatmap_idx"] = torch.tensor(
                    [self.tokenizer.beatmap_idx[generation_config.beatmap_id]], dtype=torch.long)
            else:
                model_kwargs["beatmap_idx"] = torch.tensor([self.tokenizer.num_classes], dtype=torch.long)
        if self.do_difficulty_embed:
            if generation_config.difficulty is not None:
                model_kwargs["difficulty"] = torch.tensor([generation_config.difficulty], dtype=torch.float32)
            else:
                # print("WARNING: Difficulty not provided. Selecting 5.0 for difficulty.")
                model_kwargs["difficulty"] = torch.tensor([5.0], dtype=torch.float32)
        if self.do_mapper_embed:
            if generation_config.mapper_id is not None:
                model_kwargs["mapper_idx"] = torch.tensor([self.tokenizer.get_mapper_idx(generation_config.mapper_id)],
                                                          dtype=torch.long)
            else:
                # print("WARNING: Mapper ID not provided. Selecting default mapper.")
                model_kwargs["mapper_idx"] = torch.tensor([-1], dtype=torch.long)

        return model_kwargs

    def _prepare_parallel_inputs(
            self,
            frame_times: torch.Tensor,
            song_length: float,
            in_context: list[dict[str, Any]],
            out_context: list[dict[str, Any]],
            model_kwargs: dict[str, Any],
            req_special_tokens: list[str],
    ):
        cond_prompts = []
        uncond_prompts = []
        model_kwargses = []

        for i in range(len(frame_times)):
            frame_time = frame_times[i].item()
            cond_prompt, uncond_prompt = self.get_prompts(
                self.prepare_context_sequences(in_context, frame_time, False, req_special_tokens),
                self.prepare_context_sequences(out_context, frame_time, True, req_special_tokens),
            )
            cond_prompts.append(cond_prompt)
            uncond_prompts.append(uncond_prompt)

            kwargs = model_kwargs.copy()
            # Prepare additional model kwargs
            if self.do_song_position_embed:
                global_pos_start = frame_time / song_length
                global_pos_end = (frame_time + self.miliseconds_per_sequence) / song_length
                kwargs["song_position"] = torch.tensor([global_pos_start, global_pos_end], dtype=torch.float32).unsqueeze(0)
            model_kwargses.append(kwargs)

        return cond_prompts, uncond_prompts, model_kwargses

    def _batched_inference(
            self,
            generate_func,
            cond_prompts: list[torch.Tensor],
            uncond_prompts: list[torch.Tensor],
            frames: torch.Tensor,
            model_kwargses: list[dict[str, torch.Tensor]],
            verbose: bool = True,
    ):
        cond_prompt, uncond_prompt, max_len = self.stack_prompts(cond_prompts, uncond_prompts)

        # Split prompts and uncond_prompt into batches
        max_batch_size = max(1, self.max_batch_size // self.num_beams // (2 if self.cfg_scale > 1 else 1))
        num_samples = cond_prompt.size(0)
        model_kwarg_keys = list(model_kwargses[0].keys())

        # Process each batch
        tokens_per_second_meter = self._create_tokens_per_second_meter()
        iterator = tqdm(list(range(0, num_samples, max_batch_size)), dynamic_ncols=True) if verbose else range(0, num_samples, max_batch_size)
        for i in iterator:
            frames_batch = frames[i:i + max_batch_size]
            cond_prompt_batch = cond_prompt[i:i + max_batch_size]
            uncond_prompt_batch = uncond_prompt[i:i + max_batch_size] if uncond_prompt is not None else None
            kwargses_batch = model_kwargses[i:i + max_batch_size]
            model_kwargs_batch = {k: torch.cat([kwargs[k] for kwargs in kwargses_batch], dim=0) for k in
                                  model_kwarg_keys}

            # Start generation
            result = generate_func(
                model_kwargs_batch | dict(
                    inputs=frames_batch,
                    decoder_input_ids=cond_prompt_batch,
                    decoder_attention_mask=cond_prompt_batch.ne(self.tokenizer.pad_id),
                    negative_prompt=uncond_prompt_batch,
                    negative_prompt_attention_mask=uncond_prompt_batch.ne(
                        self.tokenizer.pad_id) if uncond_prompt_batch is not None else None,
                ),
            )

            generation_stats = None
            if isinstance(result, tuple) and len(result) == 2:
                result, generation_stats = result

            self._record_generation_stats(generation_stats)
            if verbose:
                self._update_tokens_per_second_meter(iterator, tokens_per_second_meter, generation_stats)

            yield result, generation_stats

        torch.cuda.empty_cache()

    def _get_token_context(self, tokens: torch.Tensor, sos, eos, strict=False):
        """Get the start and end indices of the token context in the given tokens."""
        start = (tokens == sos).nonzero(as_tuple=True)[0]
        start = start[0] + 1 if len(start) > 0 else (None if strict else 0)
        end = (tokens == eos).nonzero(as_tuple=True)[0]
        end = end[0] if len(end) > 0 else (None if strict else len(tokens))
        if start is None or end is None:
            return 0, 0
        return start, end

    def split_into_batches(self, tensor, max_batch_size, batch_size=1):
        if tensor is None:
            return [None] * batch_size
        return [tensor[i:i + max_batch_size] for i in range(0, tensor.size(0), max_batch_size)]

    def prepare_frames(self, frames: torch.Tensor) -> torch.Tensor:
        if frames.dim() == 1:
            frames = frames.unsqueeze(0)

        return frames

    def pad_prompts(self, prompts):
        max_len = max(tensor.size(1) if tensor is not None else 0 for tensor in prompts)
        paddings = [(max_len - tensor.size(1), 0) if tensor is not None else (0, 0) for tensor in prompts]
        prompts = [torch.nn.functional.pad(tensor, paddings[i]) if tensor is not None else None for i, tensor in enumerate(prompts)]
        return prompts, max_len

    def stack_prompts(self, cond_prompts, uncond_prompts):
        length = len(cond_prompts)
        padded_prompts, max_len = self.pad_prompts(cond_prompts + uncond_prompts)
        cond_prompt = torch.cat(padded_prompts[:length], dim=0)

        if self.cfg_scale > 1:
            uncond_prompt = torch.cat(padded_prompts[length:], dim=0)
        else:
            uncond_prompt = None

        return cond_prompt, uncond_prompt, max_len

    def get_context(
            self,
            context: ContextType,
            *,
            beatmap_path: Optional[str] = None,
            extra_in_context: Optional[dict[ContextType, tuple[list[Event], list[int]] | tuple[list[Event], list[int], torch.Tensor] | list[TimingPoint]]] = None,
            song_length: Optional[float] = None,
            add_type: bool = False,
            add_class: bool = False,
            finished: bool = False,
            partial: bool = False,
            parser: Optional[OsuParser] = None,
    ):
        if context != ContextType.NONE and finished and (extra_in_context is None or context not in extra_in_context):
            beatmap_path = Path(beatmap_path)
            if not beatmap_path.is_file():
                raise FileNotFoundError(f"Beatmap file {beatmap_path} not found.")

        data = {
            "events": [],
            "event_times": [],
            "context_type": context,
            "add_type": add_type,
            "add_class": add_class,
            "add_pre_tokens": False,
            "song_length": song_length,
            "finished": finished,
        }

        if finished or partial:
            parser = parser or self.parser

            if extra_in_context is not None and context in extra_in_context:
                if context == ContextType.TIMING and isinstance(extra_in_context[context], list):
                    # This is a list of timingpoints
                    timing = extra_in_context[context]
                    data["events"], data["event_times"] = parser.parse_timing(timing, song_length=song_length)
                else:
                    if len(extra_in_context[context]) == 2:
                        data["events"], data["event_times"] = extra_in_context[context]
                    elif len(extra_in_context[context]) == 3:
                        data["events"], data["event_times"], data["class"] = extra_in_context[context]
            elif context == ContextType.NONE:
                pass
            elif context == ContextType.TIMING:
                beatmap = Beatmap.from_path(beatmap_path)
                data["events"], data["event_times"] = parser.parse_timing(beatmap, song_length=song_length)
            elif context == ContextType.MAP:
                beatmap = Beatmap.from_path(beatmap_path)
                data["events"], data["event_times"] = parser.parse(beatmap, song_length=song_length)
                if add_class:
                    data["class"] = self.get_class_vector(
                        generation_config_from_beatmap(beatmap, beatmap_path, self.tokenizer), song_length)
            elif context == ContextType.NO_HS:
                beatmap = Beatmap.from_path(beatmap_path)
                hs_events, hs_event_times = parser.parse(beatmap, song_length=song_length)
                data["events"], data["event_times"] = remove_events_of_type(hs_events, hs_event_times,
                                                                            [EventType.HITSOUND, EventType.VOLUME])
            elif context == ContextType.GD:
                beatmap = Beatmap.from_path(beatmap_path)
                data["events"], data["event_times"] = parser.parse(beatmap, song_length=song_length)
                if add_class:
                    data["class"] = self.get_class_vector(
                        generation_config_from_beatmap(beatmap, beatmap_path, self.tokenizer), song_length)
            elif context == ContextType.KIAI:
                beatmap = Beatmap.from_path(beatmap_path)
                data["events"], data["event_times"] = parser.parse_kiai(beatmap)
            elif context == ContextType.SV:
                beatmap = Beatmap.from_path(beatmap_path)
                data["events"], data["event_times"] = parser.parse_scroll_speeds(beatmap)
            else:
                raise ValueError(f"Invalid context type {context}")

            if not finished and partial:
                self._trim_events_after_time(data["events"], data["event_times"], self.start_time - 1)
        return data

    def get_in_context(
            self,
            *,
            in_context: list[ContextType],
            beatmap_path: Optional[str],
            extra_in_context: Optional[dict[ContextType, tuple[list[Event], list[int]] | tuple[list[Event], list[int], torch.Tensor] | list[TimingPoint]]] = None,
            song_length: float,
    ) -> list[dict[str, Any]]:
        in_context = [self.get_context(
            context,
            beatmap_path=beatmap_path,
            extra_in_context=extra_in_context,
            song_length=song_length,
            add_type=True,
            add_class=True,
            finished=True,
        ) for context in in_context]
        if self.add_gd_context:
            in_context.append(self.get_context(
                ContextType.GD,
                beatmap_path=beatmap_path,
                extra_in_context=extra_in_context,
                song_length=song_length,
                add_type=False,
                add_class=True,
                finished=True,
            ))
        return in_context

    def get_out_context(
            self,
            *,
            out_context: list[ContextType],
            generation_config: GenerationConfig,
            given_context: list[ContextType],
            beatmap_path: Optional[str],
            extra_in_context: Optional[dict[ContextType, tuple[list[Event], list[int]] | tuple[list[Event], list[int], torch.Tensor] | list[TimingPoint]]] = None,
            song_length: float,
            verbose: bool = True
    ) -> list[dict[str, Any]]:
        out = []
        for i, context in enumerate(out_context):
            context_is_provided = context in given_context or (
                extra_in_context is not None and context in extra_in_context
            )
            context_data = self.get_context(
                context,
                beatmap_path=beatmap_path,
                extra_in_context=extra_in_context,
                song_length=song_length,
                add_type=self.add_out_context_types,
                add_class=False,
                finished=context_is_provided,
                partial=self.add_to_beatmap and self.start_time is not None,
            )

            # Add class vector to the first out context
            if i == 0:
                context_data["class"] = self.get_class_vector(generation_config, song_length, verbose=verbose)
                context_data["negative_class"] = self.get_class_vector(GenerationConfig(
                    gamemode=generation_config.gamemode,
                    difficulty=generation_config.difficulty,
                    mapper_id=generation_config.mapper_id if (generation_config.descriptors and len(generation_config.descriptors) > 0) or (generation_config.negative_descriptors and len(generation_config.negative_descriptors) > 0) else None,
                    year=generation_config.year,
                    hp_drain_rate=generation_config.hp_drain_rate,
                    circle_size=generation_config.circle_size,
                    overall_difficulty=generation_config.overall_difficulty,
                    approach_rate=generation_config.approach_rate,
                    slider_multiplier=generation_config.slider_multiplier,
                    slider_tick_rate=generation_config.slider_tick_rate,
                    hitsounded=generation_config.hitsounded,
                    keycount=generation_config.keycount,
                    hold_note_ratio=generation_config.hold_note_ratio,
                    scroll_speed_ratio=generation_config.scroll_speed_ratio,
                    descriptors=generation_config.negative_descriptors,
                ), song_length)
                context_data["add_pre_tokens"] = self.add_pre_tokens

            out.append(context_data)
        return out

    def get_class_vector(
            self,
            config: GenerationConfig,
            song_length: float,
            verbose: bool = False,
    ):
        cond_tokens = []

        if self.add_gamemode_token:
            gamemode_token = self.tokenizer.encode_gamemode(config.gamemode)
            cond_tokens.append(gamemode_token)
        if self.add_style_token:
            style_token = self.tokenizer.encode_style(config.beatmap_id) if config.beatmap_id is not None else self.tokenizer.style_unk
            cond_tokens.append(style_token)
            if config.beatmap_id is not None and config.beatmap_id not in self.tokenizer.beatmap_idx and verbose:
                print(f"Beatmap class {config.beatmap_id} not found. Using default.")
        if self.add_diff_token:
            diff_token = self.tokenizer.encode_diff(config.difficulty) if config.difficulty is not None else self.tokenizer.diff_unk
            cond_tokens.append(diff_token)
        if self.add_mapper_token:
            mapper_token = self.tokenizer.encode_mapper_id(config.mapper_id) if config.mapper_id is not None else self.tokenizer.mapper_unk
            cond_tokens.append(mapper_token)
            if config.mapper_id is not None and config.mapper_id not in self.tokenizer.mapper_idx and verbose:
                print(f"Mapper class {config.mapper_id} not found. Using default.")
        if self.add_year_token:
            year_token = self.tokenizer.encode_year(config.year) if config.year is not None else self.tokenizer.year_unk
            cond_tokens.append(year_token)
        if self.add_hitsounded_token:
            hitsounded_token = self.tokenizer.encode(Event(EventType.HITSOUNDED, int(config.hitsounded)))
            cond_tokens.append(hitsounded_token)
        if self.add_song_length_token:
            song_length_token = self.tokenizer.encode_song_length(song_length)
            cond_tokens.append(song_length_token)
        if self.add_global_sv_token and self.add_sv and config.gamemode in [0, 2]:
            global_sv_token = self.tokenizer.encode_global_sv(config.slider_multiplier)
            cond_tokens.append(global_sv_token)
        if self.add_cs_token and config.gamemode in [0, 2]:
            cs_token = self.tokenizer.encode_cs(config.circle_size) if config.circle_size is not None else self.tokenizer.cs_unk
            cond_tokens.append(cs_token)
        if config.gamemode == 3:
            if self.add_keycount_token:
                keycount_token = self.tokenizer.encode(Event(EventType.MANIA_KEYCOUNT, config.keycount))
                cond_tokens.append(keycount_token)
            if self.add_hold_note_ratio_token:
                hold_note_ratio_token = self.tokenizer.encode_hold_note_ratio(config.hold_note_ratio) if config.hold_note_ratio is not None else self.tokenizer.hold_note_ratio_unk
                cond_tokens.append(hold_note_ratio_token)
        if self.add_scroll_speed_ratio_token and config.gamemode in [1, 3]:
            scroll_speed_ratio_token = self.tokenizer.encode_scroll_speed_ratio(config.scroll_speed_ratio) if config.scroll_speed_ratio is not None else self.tokenizer.scroll_speed_ratio_unk
            cond_tokens.append(scroll_speed_ratio_token)

        descriptors = config.descriptors if config.descriptors is not None else []
        descriptors_added = 0
        if self.add_descriptors:
            if descriptors is not None and len(descriptors) > 0:
                for descriptor in descriptors:
                    if isinstance(descriptor, str):
                        if descriptor not in self.tokenizer.descriptor_idx:
                            if verbose:
                                print(f"Descriptor class {descriptor} not found. Skipping.")
                            continue
                        cond_tokens.append(self.tokenizer.encode_descriptor_name(descriptor))
                        descriptors_added += 1
                    elif isinstance(descriptor, int):
                        if descriptor < self.tokenizer.event_range[EventType.DESCRIPTOR].min_value or \
                                descriptor > self.tokenizer.event_range[EventType.DESCRIPTOR].max_value:
                            if verbose:
                                print(f"Descriptor idx {descriptor} out of range. Skipping.")
                            continue
                        cond_tokens.append(self.tokenizer.encode_descriptor_idx(descriptor))
                        descriptors_added += 1
            if descriptors is None or descriptors_added == 0:
                cond_tokens.append(self.tokenizer.descriptor_unk)

        cond_tokens = torch.tensor(cond_tokens, dtype=torch.long).unsqueeze(0)

        return cond_tokens

    def add_predicted_tokens_to_context(
            self,
            context: dict,
            predicted_tokens,
            frame_time,
            trim_lookback: bool = False,
            trim_lookahead: bool = False
    ):
        # Trim prompt and eos tokens
        while len(predicted_tokens) > 0 and (
                predicted_tokens[-1] == self.tokenizer.eos_id or
                (context["context_type"] in self.tokenizer.context_eos and
                 predicted_tokens[-1] == self.tokenizer.context_eos[context["context_type"]])):
            predicted_tokens = predicted_tokens[:-1]

        if len(predicted_tokens) > 0 and ((trim_lookahead and predicted_tokens[-1] in self.lookahead_time_range) or
                                          (trim_lookback and predicted_tokens[-1] in self.lookback_time_range)):
            # If the type token comes before the timeshift token we should remove the type token too
            if self.types_first:
                predicted_tokens = predicted_tokens[:-2]
            else:
                predicted_tokens = predicted_tokens[:-1]

        result = self._decode(predicted_tokens, frame_time)
        context["events"] += result
        update_event_times(context["events"], context["event_times"], frame_time + self.eos_time, self.types_first)

        # Trim events which are in the lookahead window
        if trim_lookahead:
            lookahead_time = frame_time + self.lookahead_max_time
            self._trim_events_after_time(context["events"], context["event_times"], lookahead_time)

    def get_required_extra_special_tokens(self, all_out_context: list[ContextType]) -> list[str]:
        result = []
        if ContextType.KIAI in all_out_context or (self.add_kiai and any(c in all_out_context for c in [ContextType.GD, ContextType.MAP])):
            result.append("last_kiai")
        if ContextType.SV in all_out_context or ((self.add_sv or self.add_mania_sv) and any(c in all_out_context for c in [ContextType.GD, ContextType.MAP])):
            result.append("last_sv")
        if self.add_song_position_token:
            result.append("song_position")
        return result

    def prepare_context_sequences(self, contexts: list[dict], frame_time, out_context: bool, req_special_tokens: list[str]) -> list[dict]:
        results = []
        for i, context in enumerate(contexts):
            result = self.prepare_context_sequence(context, frame_time)
            results.append(result)
            # Extra special tokens are to be stored in the first output context
            if out_context and i != 0:
                for k, v in result["extra_special_events"].items():
                    results[0]["extra_special_events"][k] = v
                del result["extra_special_events"]

        # Make sure the output context has the required special tokens
        if out_context:
            for k in req_special_tokens:
                if k not in results[0]["extra_special_events"]:
                    results[0]["extra_special_events"][k] = self._default_special_event(k)

        # Tokenize extra special tokens in the correct order
        special_token_order = ["last_kiai", "last_sv", "song_position"]
        for result in results:
            if "extra_special_events" not in result:
                continue
            extra_special_events = result["extra_special_events"]
            extra_special_events = [extra_special_events[k] for k in special_token_order if k in extra_special_events]
            result["extra_special_tokens"] = self._encode(extra_special_events, frame_time)

        return results

    def prepare_context_sequence(self, context: dict, frame_time) -> dict:
        result = context.copy()
        result["frame_time"] = frame_time

        if context["add_pre_tokens"]:
            s, e = self._get_events_time_range(context["event_times"], frame_time - self.miliseconds_per_sequence, frame_time)
            pre_tokens = self._encode(context["events"][s:e], frame_time)
            if 0 <= self.max_pre_token_len < pre_tokens.shape[1]:
                pre_tokens = pre_tokens[:, -self.max_pre_token_len:]
            result["pre_tokens"] = pre_tokens

        s, e = self._get_events_time_range(context["event_times"], frame_time, frame_time + self.miliseconds_per_sequence)
        result["tokens"] = self._encode(context["events"][s:e], frame_time)

        # Prepare extra special tokens
        extra_special_events = {}
        if self.add_kiai_special_token and (context["context_type"] == ContextType.KIAI or (self.add_kiai and context["context_type"] in [ContextType.GD, ContextType.MAP])):
            extra_special_events["last_kiai"] = self._kiai_before_time(context["events"], context["event_times"], frame_time)
        if self.add_sv_special_token and (context["context_type"] == ContextType.SV or ((self.add_sv or self.add_mania_sv) and context["context_type"] in [ContextType.GD, ContextType.MAP])):
            extra_special_events["last_sv"] = self._sv_before_time(context["events"], context["event_times"], frame_time)
        if self.add_song_position_token and "class" in context:
            extra_special_events["song_position"] = self.tokenizer.encode_song_position_event(frame_time, context["song_length"])

        result["extra_special_events"] = extra_special_events

        return result

    # Prepare context type indicator tokens
    def get_context_tokens(self, context, max_token_length=None, add_type_end=True):
        context_type = context["context_type"]
        tokens = context["tokens"]

        # Trim tokens if they are too long
        if max_token_length is not None and tokens.shape[1] > max_token_length:
            tokens = tokens[:, -max_token_length:]

        to_concat = []
        if context["add_type"]:
            to_concat.append(torch.tensor([[self.tokenizer.context_sos[context_type]]], dtype=torch.long))

        if context["add_class"]:
            if "class" in context:
                to_concat.append(context["class"])
            if "extra_special_tokens" in context:
                to_concat.append(context["extra_special_tokens"])

        to_concat.append(tokens)

        if context["add_type"] and add_type_end:
            to_concat.append(torch.tensor([[self.tokenizer.context_eos[context_type]]], dtype=torch.long))

        return torch.concatenate(to_concat, dim=-1)

    def get_prompt(self, in_context, out_context, negative=False, max_token_length=None):
        class_container = out_context[0]
        user_prompt = class_container["negative_class"] if negative else class_container["class"]
        extra_special_tokens = class_container["extra_special_tokens"] if "extra_special_tokens" in class_container else torch.tensor([[]], dtype=torch.long)
        pre_tokens = class_container["pre_tokens"] if "pre_tokens" in class_container else torch.tensor([[]], dtype=torch.long)

        in_tokens = [self.get_context_tokens(context, max_token_length) for context in in_context]
        # We must not add the type end token to the last context because it should be generated by the model
        out_tokens = [self.get_context_tokens(context, max_token_length, i != len(out_context) - 1) for i, context in enumerate(out_context)]

        if max_token_length is not None:
            pre_tokens = pre_tokens[:, -max_token_length:]

        to_concat = in_tokens + [user_prompt, extra_special_tokens, pre_tokens]
        prefix = torch.concatenate(to_concat, dim=-1)

        if self.center_pad_decoder:
            prefix = F.pad(prefix, (self.tgt_seq_len // 2 - prefix.shape[1], 0), value=self.tokenizer.pad_id)

        sos = torch.tensor([[self.tokenizer.sos_id]], dtype=torch.long)
        prompt = torch.concatenate([prefix, sos] + out_tokens, dim=-1)
        return prompt

    def get_prompts(self, in_context, out_context):
        # Prepare classifier-free guidance
        cond_prompt = self.get_prompt(in_context, out_context)
        uncond_prompt = self.get_prompt(in_context, out_context, negative=True) if self.cfg_scale > 1 else None

        # Make sure the prompt is not too long
        i = 0
        max_length = self.tgt_seq_len
        while cond_prompt.shape[1] >= self.tgt_seq_len:
            i += 1
            if i > 10:
                raise ValueError("Prompt is too long.")
            max_length = max_length // 2
            cond_prompt = self.get_prompt(in_context, out_context, max_token_length=max_length)
            uncond_prompt = self.get_prompt(in_context, out_context, negative=True,
                                            max_token_length=max_length) if self.cfg_scale > 1 else None

        return cond_prompt, uncond_prompt

    def _get_events_time_range(self, event_times: list[float], start_time: float, end_time: float):
        # Look from the end of the list
        s = 0
        for i in range(len(event_times) - 1, -1, -1):
            if event_times[i] < start_time:
                s = i + 1
                break
        e = 0
        for i in range(len(event_times) - 1, -1, -1):
            if event_times[i] < end_time:
                e = i + 1
                break
        return s, e

    def _trim_events_before_time(self, events, event_times, time):
        for i in range(len(event_times) - 1, -1, -1):
            if event_times[i] < time:
                del events[i]
                del event_times[i]

    def _trim_events_after_time(self, events, event_times, time):
        for i in range(len(event_times) - 1, -1, -1):
            if event_times[i] > time:
                del events[i]
                del event_times[i]
            else:
                break

    def _encode(self, events: list[Event], frame_time: float) -> torch.Tensor:
        tokens = torch.empty((1, len(events)), dtype=torch.long)
        timeshift_range = self.tokenizer.event_range[EventType.TIME_SHIFT]
        for i, event in enumerate(events):
            if event.type == EventType.TIME_SHIFT:
                value = int((event.value - frame_time) / MILISECONDS_PER_STEP)
                value = np.clip(value, timeshift_range.min_value, timeshift_range.max_value)
                event = Event(type=event.type, value=value)
            tokens[0, i] = self.tokenizer.encode(event)
        return tokens

    def _decode(
            self,
            tokens: torch.Tensor,
            frame_time: float,
            allow_non_events: bool = False,
    ) -> list[Event]:
        """Converts a list of tokens into Event objects and converts to absolute time values.

        Args:
            tokens: List of tokens.
            frame time: Start time of current source sequence.

        Returns:
            events: List of Event objects.
        """
        events = []
        for token in tokens:
            if token == self.tokenizer.eos_id and not allow_non_events:
                break

            try:
                event = self.tokenizer.decode(token.item())
            except:
                if allow_non_events:
                    events.append(Event(EventType.CONTROL, token.item()))
                continue

            if event.type == EventType.TIME_SHIFT:
                # Half-step (+5ms) de-biasing. Time shifts are encoded to the 10ms
                # token grid by truncation (int((ms - start) * STEPS_PER_MILLISECOND)
                # in data_utils / _encode), so a decoded step represents the floor
                # of the true time. Multiplying straight back biases every event
                # ~5ms early (measured mean -4.82ms, median -5.0ms over 50k time
                # shifts from ranked maps). Adding half a step recenters the
                # quantization error to ~0 (mean -4.82 -> +0.18ms). This is
                # self-consistent with _encode's truncation on context round-trips:
                # the +5 is truncated back to the same step.
                half_step = MILISECONDS_PER_STEP // 2 if event.value >= 0 else 0
                event.value = frame_time + event.value * MILISECONDS_PER_STEP + half_step

            events.append(event)

        return events

    def _rescale_positions(self, events: list[Event], event_times: list[int]) -> tuple[list[Event], list[int]]:
        new_events = []
        new_event_times = []
        default_offset = self.position_precision // 2 if self.position_precision > 1 else 0
        default_offset = np.array([default_offset, default_offset], dtype=np.int32)
        for i, event in enumerate(events):
            if event.type == EventType.POS_X or event.type == EventType.POS_Y:
                new_events.append(Event(type=event.type, value=event.value * self.position_precision))
                new_event_times.append(event_times[i])
            elif event.type == EventType.POS:
                if i + 1 < len(events) and events[i + 1].type == EventType.POS_REFINE and self.position_refinement:
                    refinement_range = self.position_precision // self.position_refinement
                    refinement = events[i + 1].value
                    offset = np.array([refinement % refinement_range, refinement // refinement_range], dtype=np.int32) * self.position_refinement
                else:
                    offset = default_offset

                p = np.array([event.value % self.x_count + self.x_min, event.value // self.x_count + self.y_min], dtype=np.int32)
                p *= self.position_precision
                p += offset
                new_events.append(Event(type=EventType.POS_X, value=p[0]))
                new_events.append(Event(type=EventType.POS_Y, value=p[1]))
                new_event_times.append(event_times[i])
                new_event_times.append(event_times[i])
            else:
                new_events.append(event)
                new_event_times.append(event_times[i])

        return new_events, new_event_times

    def _kiai_before_time(self, events, event_times, time) -> Event:
        for i in range(len(events) - 1, -1, -1):
            if events[i].type == EventType.KIAI and event_times[i] < time:
                return events[i]
        return self._default_special_event("last_kiai")

    def _sv_before_time(self, events, event_times, time) -> Event:
        for i in range(len(events) - 1, -1, -1):
            if events[i].type == EventType.SCROLL_SPEED and event_times[i] < time:
                return events[i]
        return self._default_special_event("last_sv")

    def _default_special_event(self, name: str) -> Event:
        if name == "last_kiai":
            return Event(EventType.KIAI, 0)
        if name == "last_sv":
            return Event(EventType.SCROLL_SPEED, 100)
        raise ValueError(f"Invalid special event name {name}.")

    def _convert_column_to_position(self, events, event_times, key_count) -> tuple[list[Event], list[int]]:
        new_events = []
        new_event_times = []
        for i, event in enumerate(events):
            if event.type == EventType.MANIA_COLUMN:
                x = int((event.value + 0.5) * 512 / key_count)
                new_events.append(Event(EventType.POS_X, x))
                new_events.append(Event(EventType.POS_Y, 192))
                new_event_times.append(event_times[i])
                new_event_times.append(event_times[i])
            else:
                new_events.append(event)
                new_event_times.append(event_times[i])
        return new_events, new_event_times

    def _reset_generation_stats(self) -> None:
        self.last_generation_stats = {
            "generated_tokens": 0,
            "elapsed_seconds": 0.0,
            "tokens_per_second": 0.0,
        }

    def _record_generation_stats(self, stats: Any) -> None:
        if not isinstance(stats, dict):
            return

        if self.last_generation_stats is None:
            self._reset_generation_stats()

        generated_tokens = int(stats.get("generated_tokens", 0) or 0)
        elapsed_seconds = float(stats.get("elapsed_seconds", 0.0) or 0.0)
        self.last_generation_stats["generated_tokens"] += generated_tokens
        self.last_generation_stats["elapsed_seconds"] += elapsed_seconds

        total_elapsed = float(self.last_generation_stats["elapsed_seconds"])
        total_tokens = int(self.last_generation_stats["generated_tokens"])
        self.last_generation_stats["tokens_per_second"] = total_tokens / total_elapsed if total_elapsed > 0 else 0.0

    @staticmethod
    def _create_tokens_per_second_meter(alpha: float = 0.1) -> dict[str, float | None]:
        return {"alpha": alpha, "ema": None}

    @staticmethod
    def _update_tokens_per_second_meter(progress_bar, meter: dict[str, float | None], stats: Any) -> None:
        if progress_bar is None or not isinstance(stats, dict):
            return

        tokens_per_second = stats.get("tokens_per_second")
        if tokens_per_second is None or tokens_per_second <= 0:
            return

        previous = meter.get("ema")
        alpha = float(meter.get("alpha", 0.1))
        meter["ema"] = float(tokens_per_second) if previous is None else (alpha * float(tokens_per_second) + (1 - alpha) * float(previous))
        progress_bar.set_postfix_str(f"{meter['ema']:.1f} tok/s", refresh=False)
